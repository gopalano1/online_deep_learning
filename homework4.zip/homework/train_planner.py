"""
Usage:
    python3 -m homework.train_planner --your_args here
"""

print("Time to train")
